#include "CTable.h"
#include <iostream>
#include <string>

CTable::CTable()
{
	s_name = DEFAULT_NAME;
	i_tab_length = DEFAULT_LEN;
	pi_tab = new int[i_tab_length];
	std::cout << "bezp: '"<< s_name << "'" << std::endl;
}

CTable::CTable(std::string sName, int iTableLen)
{
	if (iTableLen > 0) {
		s_name = sName;
		i_tab_length = iTableLen;
		pi_tab = new int[i_tab_length];
		std::cout << "parametr: '" << s_name << "'" << std::endl;
	}
	std::cout << "Rozmiar tablicy jest mniejszy od 0!" << std::endl;
}

CTable::CTable(CTable & pcOther)
{
	s_name = pcOther.s_name + "_copy";
	i_tab_length = pcOther.i_tab_length;
	pi_tab = new int[i_tab_length];

	for (int ii = 0; ii < i_tab_length; ii++) {
		pi_tab[ii] = pcOther.pi_tab[ii];
	}
	std::cout << "kopiuj: '" << s_name << "'" << std::endl;
}

CTable::~CTable()
{
	std::cout << "usuwam: '" << s_name << "'" << std::endl;
	delete pi_tab;
}

void CTable::vSetName(std::string sName)
{
	s_name = sName;
}

bool CTable::bSetNewSize(int iTableLen)
{
	if (iTableLen > 0) {
		if (iTableLen < i_tab_length) {
			i_tab_length = iTableLen;
			std::cout << "Nowy rozmiar tablicy mniejszy niz poczatkowy - mozliwa utrata czesci elementow" << std::endl;
		}
		int* newTable = new int[i_tab_length];
		for (int ii = 0; ii < i_tab_length; ii++) {
			newTable[ii] = pi_tab[ii];
		}
		delete pi_tab;
		pi_tab = newTable;
		return true;
	}
	std::cout << "Rozmiar tablicy jest mniejszy od 0!" << std::endl;
	return false;
}

CTable * CTable::pcClone()
{
	return new CTable(*(this));
}
