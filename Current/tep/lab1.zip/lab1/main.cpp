#include <iostream>
#include "CTable.h"

void v_alloc_table_add_5(int iSize);
bool b_alloc_table_2_dim(int ***piTable, int iSizeX, int iSizeY);
//***piTable by� potrzebny, poniewa� przy **piTable przekazujemy niezainicjowany obiekt do funkcji.
bool b_dealloc_table_2_dim(int ***piTable, int iSizeX, int iSizeY);

void v_mod_tab(CTable *pcTab, int iNewSize);
void v_mod_tab(CTable cTab, int iNewSize);

int main(){
	v_alloc_table_add_5(10);
	int** pi_table;

	bool resAlloc = b_alloc_table_2_dim(&pi_table, 5, 3);
	bool resDealloc = b_dealloc_table_2_dim(&pi_table, 5, 3);
	std::cout << resAlloc << " " << resDealloc << std::endl;

	CTable c_tab;
	CTable *pc_new_tab;
	CTable *pc_new_tab2;

	pc_new_tab = c_tab.pcClone();
	pc_new_tab2 = c_tab.pcClone();

	std::cout << "mod1 (*pc) " << std::endl;
	std::cout << "przed: " << pc_new_tab << std::endl;
	v_mod_tab(pc_new_tab, 7);
	std::cout << "po: " << pc_new_tab << std::endl;

	std::cout << "\nmod2 (c)" << std::endl;
	std::cout << "przed " << pc_new_tab2 << std::endl;
	v_mod_tab((*pc_new_tab2), 7);
	std::cout << "po: " << pc_new_tab2 << std::endl;

	return 0;
}

void v_alloc_table_add_5(int iSize){
	if (iSize > 0) {

		int* pi_tab = new int[iSize];
		for (int ii = 0; ii < iSize; ii++) {
			pi_tab[ii] = ii + 5;
		}
		std::cout << "utworzono tablice: ";
		for (int jj = 0; jj < iSize; jj++) {
			std::cout << pi_tab[jj] << " ";
		}
		std::cout << std::endl;
	}
}

bool b_alloc_table_2_dim(int ***piTable, int iSizeX, int iSizeY){
	if (iSizeX > 0 && iSizeY > 0) {
		*piTable = new int*[iSizeX];
		for (int ii = 0; ii < iSizeX; ii++) {
			(*piTable)[ii] = new int[iSizeY];
		}
		return true;
	}
	std::cout << "Niewlasciwe wymiary tablic!" << std::endl;
	return false;
}

bool b_dealloc_table_2_dim(int ***piTable, int iSizeX, int iSizeY){
	for (int ii = 0; ii < iSizeX; ii++) {
		delete (*piTable)[ii];
	}
	delete *piTable;
	return true;
}

void v_mod_tab(CTable * pcTab, int iNewSize)
{
	pcTab->bSetNewSize(iNewSize);
}

void v_mod_tab(CTable cTab, int iNewSize)
{
	cTab.bSetNewSize(iNewSize);
}
