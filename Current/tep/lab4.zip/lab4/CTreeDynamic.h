#pragma once
#include "CNodeDynamic.h"
template <typename T>
class CTreeDynamic {
public:
	CTreeDynamic();
	CTreeDynamic(CNodeDynamic<T> * pcRoot);
	~CTreeDynamic();

	CNodeDynamic<T>* pcGetRoot();
	void vPrintTree();
	
	bool bMoveSubtree(CNodeDynamic<T>* pcParentNode, CNodeDynamic<T>* pcNewChildNode);


private:
	CNodeDynamic<T>* pc_root;
};

template <typename T>
CTreeDynamic<T>::CTreeDynamic()
{
}

template <typename T>
CTreeDynamic<T>::CTreeDynamic(CNodeDynamic<T> * pcRoot)
{
	pc_root = pcRoot;
}

template <typename T>
CTreeDynamic<T>::~CTreeDynamic()
{
}

template <typename T>
CNodeDynamic<T>* CTreeDynamic<T>::pcGetRoot()
{
	return pc_root;
}

template <typename T>
void CTreeDynamic<T>::vPrintTree()
{
	pc_root->vPrintAllBelow();
}

template <typename T>
bool CTreeDynamic<T>::bMoveSubtree(CNodeDynamic<T>* pcParentNode, CNodeDynamic<T>* pcNewChildNode)
{
	if (pcParentNode != NULL) {
		CNodeDynamic<T>* pcOldParent = pcNewChildNode->getParent();
		if (pcOldParent != NULL) {
			std::cout << "Przenoszony wezel ma parenta" << std::endl;
			std::vector<CNodeDynamic<T>*>* vOldParentChildren = pcOldParent->vGetChildren();
			for (size_t ii = 0; ii < (*vOldParentChildren).size(); ii++) {
				if (pcNewChildNode == (*vOldParentChildren)[ii]) {
					std::cout << "znaleziono odpowiedni wezel" << std::endl;
					(*vOldParentChildren).erase((*vOldParentChildren).begin() + ii);
					pcParentNode->vAddNewChild(pcNewChildNode); //metoda vAddNewChild automatycznie nadpisze parenta dla cTargetNode
					return true;
				}
			}
		}
		else {
			std::cout << "Parent przenoszonego poddrzewa nie istnieje" << std::endl;
			pcParentNode->vAddNewChild(pcNewChildNode); //metoda vAddChild automatycznie przypisze parenta dla cTargetNode
			return true;
		}
	}
	std::cout << "nowy parent nie istnieje, nie ma co przenosic" << std::endl;
	return false;
}
