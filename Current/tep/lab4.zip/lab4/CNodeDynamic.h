#pragma once
#include <vector>

template <typename T>class CNodeDynamic {
public:
	CNodeDynamic();
	~CNodeDynamic();
	void vSetValue(T iNewVal);

	int iGetChildrenNumber();
	void vAddNewChild();
	void vAddNewChild(CNodeDynamic* pcNewNode);
	CNodeDynamic* pcGetChild(int iChildOffset);
	CNodeDynamic* getParent();
	std::vector<CNodeDynamic*>* vGetChildren();

	void vPrint();
	void vPrintAllBelow();

	//mod
	bool isConsistentNodes();

private:
	std::vector<CNodeDynamic*> v_children;
	CNodeDynamic *pc_parent_node;
	T i_val;
};

template <typename T>
CNodeDynamic<T>::CNodeDynamic()
{
	i_val = 0;
	pc_parent_node = NULL;
}

template <typename T>
CNodeDynamic<T>::~CNodeDynamic()
{
}

template <typename T>
void CNodeDynamic<T>::vSetValue(T newVal)
{
	i_val = newVal;
}

template <typename T>
int CNodeDynamic<T>::iGetChildrenNumber()
{
	return v_children.size();
}

template <typename T>
void CNodeDynamic<T>::vAddNewChild()
{
	CNodeDynamic<T>* newNode = new CNodeDynamic<T>();
	newNode->pc_parent_node = this;
	v_children.push_back(newNode);
}

template <typename T>
void CNodeDynamic<T>::vAddNewChild(CNodeDynamic<T> * pcNewNode)
{
	pcNewNode->pc_parent_node = this;
	v_children.push_back(pcNewNode);
}

template <typename T>
CNodeDynamic<T>* CNodeDynamic<T>::pcGetChild(int iChildOffset)
{
	return v_children[iChildOffset];
}

template <typename T>
CNodeDynamic<T>* CNodeDynamic<T>::getParent()
{
	if (pc_parent_node == NULL) return NULL;
	return pc_parent_node;
}

template <typename T>
std::vector<CNodeDynamic<T>*>* CNodeDynamic<T>::vGetChildren()
{
	return &v_children;
}

template <typename T>
void CNodeDynamic<T>::vPrint()
{
	std::cout << " " << i_val;
}

template <typename T>
void CNodeDynamic<T>::vPrintAllBelow()
{
	vPrint();
	for (int ii = 0; ii < this->iGetChildrenNumber(); ii++) {
		v_children[ii]->vPrintAllBelow();
	}
}

template <typename T>
bool CNodeDynamic<T>::isConsistentNodes()
{
	bool output = true;

	for (int ii = 0; ii < this->iGetChildrenNumber(); ii++) {
		if (this->v_children[ii]->iGetChildrenNumber() != 0)
			output = this->v_children[ii]->isConsistentNodes();
		if (!output) return false;
	}
	if (this->pc_parent_node != NULL) {

	}
}

//mod
