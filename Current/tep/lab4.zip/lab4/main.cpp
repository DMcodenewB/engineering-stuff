#include "CNodeDynamic.h"
#include "CTreeDynamic.h"
#include <iostream>

void v_dynamic_tree_test();

int main() {

	v_dynamic_tree_test();

	return 0;
}

void v_dynamic_tree_test()
{
	CNodeDynamic<int>* pc_root = new CNodeDynamic<int>();
	CNodeDynamic<int>* pc_root2 = new CNodeDynamic<int>();
	CTreeDynamic<int>* pc_tree = new CTreeDynamic<int>(pc_root);
	CTreeDynamic<int>* pc_tree2 = new CTreeDynamic<int>(pc_root2);
	
	pc_tree->pcGetRoot()->vAddNewChild();
	pc_tree->pcGetRoot()->vAddNewChild();
	pc_tree->pcGetRoot()->pcGetChild(0)->vSetValue(3);
	pc_tree->pcGetRoot()->pcGetChild(1)->vSetValue(4);
	pc_tree->pcGetRoot()->pcGetChild(0)->vAddNewChild();
	pc_tree->pcGetRoot()->pcGetChild(0)->vAddNewChild();
	pc_tree->pcGetRoot()->pcGetChild(0)->pcGetChild(0)->vSetValue(31);
	pc_tree->pcGetRoot()->pcGetChild(0)->pcGetChild(1)->vSetValue(32);
	pc_tree->pcGetRoot()->pcGetChild(1)->vAddNewChild();
	pc_tree->pcGetRoot()->pcGetChild(1)->vAddNewChild();
	pc_tree->pcGetRoot()->pcGetChild(1)->pcGetChild(0)->vSetValue(41);
	pc_tree->pcGetRoot()->pcGetChild(1)->pcGetChild(1)->vSetValue(42);


	pc_tree2->pcGetRoot()->vAddNewChild();
	pc_tree2->pcGetRoot()->vAddNewChild();
	pc_tree2->pcGetRoot()->pcGetChild(0)->vSetValue(5);
	pc_tree2->pcGetRoot()->pcGetChild(1)->vSetValue(6);
	pc_tree2->pcGetRoot()->pcGetChild(0)->vAddNewChild();
	pc_tree2->pcGetRoot()->pcGetChild(0)->vAddNewChild();
	pc_tree2->pcGetRoot()->pcGetChild(0)->pcGetChild(0)->vSetValue(51);
	pc_tree2->pcGetRoot()->pcGetChild(0)->pcGetChild(1)->vSetValue(52);
	pc_tree2->pcGetRoot()->pcGetChild(1)->vAddNewChild();
	pc_tree2->pcGetRoot()->pcGetChild(1)->vAddNewChild();
	pc_tree2->pcGetRoot()->pcGetChild(1)->pcGetChild(0)->vSetValue(61);
	pc_tree2->pcGetRoot()->pcGetChild(1)->pcGetChild(1)->vSetValue(62);

	pc_tree->vPrintTree();
	std::cout << std::endl;
	pc_tree2->vPrintTree();
	std::cout << std::endl;

	pc_tree->bMoveSubtree(pc_tree->pcGetRoot()->pcGetChild(0)->pcGetChild(0), pc_tree2->pcGetRoot()->pcGetChild(1)->pcGetChild(1));
	
	std::cout << "\npo_zmianie" << std::endl;
	pc_tree->vPrintTree();
	std::cout << std::endl;
	pc_tree2->vPrintTree();
	std::cout << std::endl;


	
}
