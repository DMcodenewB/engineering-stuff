#include "CNodeDynamic.h"
#include <iostream>

