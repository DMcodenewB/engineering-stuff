#pragma once
#include <string>
#include <iostream>

#define DEFAULT_NAME "deftab"
#define DEFAULT_LEN 5

class CTable {
public:
	CTable();
	CTable(std::string sName, int iTableLen);
	CTable(CTable& pcOther);
	~CTable();

	void vSetName(std::string sName);
	bool bSetNewSize(int iTableLen);
	void vSetValueAt(int iOffset, int iNewVal);
	void vPrint();
	CTable* pcClone();

	CTable* operator+(const CTable &other);
	friend std::ostream& operator<<(std::ostream& output, const CTable& pcTab);
	friend CTable& operator<<=(CTable& pcTab, int element);
	
private:
	std::string s_name;
	int* pi_tab;
	int i_tab_length;
};