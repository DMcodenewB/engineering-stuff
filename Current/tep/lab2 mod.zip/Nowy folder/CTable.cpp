#include "CTable.h"
#include <string>

CTable::CTable()
{
	s_name = DEFAULT_NAME;
	i_tab_length = DEFAULT_LEN;
	pi_tab = new int[i_tab_length];
	std::cout << "bezp: '"<< s_name << "'" << std::endl;
}

CTable::CTable(std::string sName, int iTableLen)
{
	if (iTableLen > 0) {
		s_name = sName;
		i_tab_length = iTableLen;
		pi_tab = new int[i_tab_length];
		std::cout << "parametr: '" << s_name << "'" << std::endl;
	}
	else std::cout << "Rozmiar tablicy jest mniejszy od 0!" << std::endl;
}

CTable::CTable(CTable & pcOther)
{
	s_name = pcOther.s_name + "_copy";
	i_tab_length = pcOther.i_tab_length;
	pi_tab = new int[i_tab_length];

	for (int ii = 0; ii < i_tab_length; ii++) {
		pi_tab[ii] = pcOther.pi_tab[ii];
	}
	std::cout << "kopiuj: '" << s_name << "'" << std::endl;
}

CTable::~CTable()
{
	std::cout << "usuwam: '" << s_name << "'" << std::endl;
	delete pi_tab;
}

void CTable::vSetName(std::string sName)
{
	s_name = sName;
}

bool CTable::bSetNewSize(int iTableLen)
{
	if (iTableLen > 0) {
		if (iTableLen < i_tab_length) {
			std::cout << "Nowy rozmiar tablicy mniejszy niz poczatkowy - mozliwa utrata czesci elementow" << std::endl;
		}
		i_tab_length = iTableLen;
		int* newTable = new int[i_tab_length];
		for (int ii = 0; ii < i_tab_length; ii++) {
			newTable[ii] = pi_tab[ii];
		}
		delete pi_tab;
		pi_tab = newTable;
		return true;
	}
	std::cout << "Rozmiar tablicy jest mniejszy od 0!" << std::endl;
	return false;
}

void CTable::vSetValueAt(int iOffset, int iNewVal)
{
	if (iOffset >= 0 && iOffset <= i_tab_length) {
		pi_tab[iOffset] = iNewVal;
	}
}

void CTable::vPrint()
{
	std::cout << s_name << ": " << *this << std::endl;
}

CTable * CTable::pcClone()
{
	return new CTable(*(this));
}

CTable* CTable::operator+(const CTable &other)
{
	int size = i_tab_length + other.i_tab_length;
	CTable * new_tab = new CTable("concat", size);
	for (int ii = 0; ii < i_tab_length; ii++) {
		new_tab->vSetValueAt(ii, pi_tab[ii]);
	}
	for (int ij = 0; ij < other.i_tab_length; ij++) {
		new_tab->vSetValueAt(ij + i_tab_length, other.pi_tab[ij]);
	}
	new_tab->i_tab_length = size;
	return new_tab;
}

std::ostream& operator<<(std::ostream& output, const CTable& pcTab) {
	output << "[";
	for (int ii = 0; ii < pcTab.i_tab_length; ii++) {
		output << pcTab.pi_tab[ii];

		if (ii != pcTab.i_tab_length - 1)
			output << ", ";
	}
	output << "]";

	return output;
}

CTable& operator<<=(CTable& pcTab, int element) {
	pcTab.bSetNewSize(pcTab.i_tab_length + 1);
	pcTab.vSetValueAt(pcTab.i_tab_length - 1, element);
	return pcTab;
}
