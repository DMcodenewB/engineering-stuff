#include "CTable.h"

void v_alloc_table_add_5(int iSize);
bool b_alloc_table_2_dim(int ***piTable, int iSizeX, int iSizeY);
//***piTable by� potrzebny, poniewa� przy **piTable przekazujemy niezainicjowany obiekt do funkcji.
bool b_dealloc_table_2_dim(int ***piTable, int iSizeX, int iSizeY);

void v_mod_tab(CTable *pcTab, int iNewSize);
void v_mod_tab(CTable cTab, int iNewSize);

//modyfikacja na zaj�ciach
//int*** allocateTable2DBlock(int sizeX, int sizeY);
//void deallocateTable2DBlock(int ***piTable, int iSizeX);

int main(){
	//lista 1
	std::cout << "Lista 1" << std::endl;

	v_alloc_table_add_5(10);
	int** pi_table;
	bool resAlloc = b_alloc_table_2_dim(&pi_table, 5, 3);
	bool resDealloc = b_dealloc_table_2_dim(&pi_table, 5, 3);
	std::cout << resAlloc << " " << resDealloc << std::endl;

	CTable c_tab;
	CTable *pc_new_tab;
	CTable *pc_new_tab2;

	c_tab.vSetName("zad1");

	pc_new_tab = c_tab.pcClone();
	pc_new_tab2 = c_tab.pcClone();

	std::cout << "mod1 (*pc) " << std::endl;
	std::cout << "przed: " << pc_new_tab << std::endl;
	v_mod_tab(pc_new_tab, 7);
	std::cout << "po: " << pc_new_tab << std::endl;

	std::cout << "\nmod2 (c)" << std::endl;
	std::cout << "przed " << pc_new_tab2 << std::endl;
	v_mod_tab((*pc_new_tab2), 7);
	std::cout << "po: " << pc_new_tab2 << std::endl;


	//modyfikacja na zaj�ciach
	/*int ***newTab = allocateTable2DBlock(10, 5);
	deallocateTable2DBlock(newTab, 10);*/
	
	//lista 2
	std::cout << "\n=============================================================\nLista 2\n" << std::endl;
	CTable c_tab_0, c_tab_1, c_tab_2;
	c_tab_0.vSetName("zad2tab0");
	c_tab_1.vSetName("zad2tab1");
	c_tab_0.bSetNewSize(6);
	c_tab_1.bSetNewSize(4); //print o utracie cz�ci element�w
	
	c_tab_0.vSetValueAt(0, 1);
	c_tab_0.vSetValueAt(1, 2);
	c_tab_0.vSetValueAt(2, 3);
	c_tab_0.vSetValueAt(3, 4);
	c_tab_0.vSetValueAt(4, 5);
	c_tab_0.vSetValueAt(5, 6);

	c_tab_1.vSetValueAt(0, 51);
	c_tab_1.vSetValueAt(1, 52);
	c_tab_1.vSetValueAt(2, 53);
	c_tab_1.vSetValueAt(3, 54);

	//c_tab_0 = c_tab_1;
	//odp 1. Przy pr�bie zamkni�cia programu pojawia si� b��d przy dealokacji obiekt�w. Podejrzenie: nast�pi�o przepisanie adresu i pr�ba dwukrotnego usuni�cia tego samego obiektu.
	//odp 2. Program si� wykona�, ale podejrzewam, �e nast�pi� memory leak przy przepisaniu adresu c_tab_1 na c_tab_0, bo obiekt pod c_tab_0 nie zostanie usuni�ty
	
	c_tab_0.vPrint();
	c_tab_1.vPrint();
	c_tab_1.vSetValueAt(2, 123);
	//odp 3. Tak jak podejrzewa�em, sprawdzi� si� scenariusz z odp.1 i 2.

	c_tab_2 = *(c_tab_0.operator+(c_tab_1));
	c_tab_2.vPrint();

	std::cout << (c_tab_2 <<= 1000) << std::endl;
	(c_tab_2 <<= 690).vPrint();

	return 0;
}

void v_alloc_table_add_5(int iSize){
	if (iSize > 0) {

		int* pi_tab = new int[iSize];
		for (int ii = 0; ii < iSize; ii++) {
			pi_tab[ii] = ii + 5;
		}
		std::cout << "utworzono tablice: ";
		for (int jj = 0; jj < iSize; jj++) {
			std::cout << pi_tab[jj] << " ";
		}
		std::cout << std::endl;
	}
}

bool b_alloc_table_2_dim(int ***piTable, int iSizeX, int iSizeY){
	if (iSizeX > 0 && iSizeY > 0) {
		*piTable = new int*[iSizeX];
		for (int ii = 0; ii < iSizeX; ii++) {
			(*piTable)[ii] = new int[iSizeY];
		}
		return true;
	}
	std::cout << "Niewlasciwe wymiary tablic!" << std::endl;
	return false;
}

bool b_dealloc_table_2_dim(int ***piTable, int iSizeX, int iSizeY){
	for (int ii = 0; ii < iSizeX; ii++) {
		delete (*piTable)[ii];
	}
	delete *piTable;
	return true;
}

void v_mod_tab(CTable * pcTab, int iNewSize)
{
	pcTab->bSetNewSize(iNewSize);
}

void v_mod_tab(CTable cTab, int iNewSize)
{
	cTab.bSetNewSize(iNewSize);
}

//modyfikacja na zaj�ciach
//int*** allocateTable2DBlock(int sizeX, int sizeY) {
//	if (sizeX > 0 && sizeY > 0) {
//		int sizeMul = sizeX * sizeY;
//		int** piTab = new int*[sizeX];
//		int* tab = new int[sizeMul];
//		int offset = 0;
//
//		for (int ii = 0; ii < sizeX; ii++) {
//			piTab[ii] = &(tab[offset]);
//			offset += sizeY;
//		}
//		return &piTab;
//	}
//	std::cout << "Niewlasciwe wymiary tablicy!" << std::endl;
//	return nullptr;
//}
//
//void deallocateTable2DBlock(int ***piTable, int iSizeX) {
//	int offset = 0;
//	for (int ii = 0; ii < iSizeX; ii++) {
//		delete *piTable[ii];
//	}
//	delete *piTable;
//}